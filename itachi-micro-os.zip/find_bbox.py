import struct
import zlib

with open(r"D:\slax\boot\grub\bootlogo.png", "rb") as f:
    data = f.read()

pos = 8
idat_chunks = []
w, h, depth, color_type = 0, 0, 0, 0
while pos < len(data):
    length, chunk_type = struct.unpack(">I4s", data[pos:pos+8])
    pos += 8
    chunk_data = data[pos:pos+length]
    pos += length + 4
    if chunk_type == b"IHDR":
        w, h, depth, color_type = struct.unpack(">IIBB", chunk_data[:10])
    elif chunk_type == b"IDAT":
        idat_chunks.append(chunk_data)
    elif chunk_type == b"IEND":
        break

raw_idat = zlib.decompress(b"".join(idat_chunks))
print(f"Image: {w}x{h}, depth={depth}, color_type={color_type}, raw_size={len(raw_idat)}")

# Color type 6 is RGBA (4 bytes per pixel), color type 2 is RGB (3 bytes per pixel)
bytes_per_pixel = 4 if color_type == 6 else 3
row_size = 1 + w * bytes_per_pixel

# Find min_y, max_y, min_x, max_x of non-black pixels
min_x, max_x, min_y, max_y = w, 0, h, 0
for y in range(h):
    row = raw_idat[y*row_size : (y+1)*row_size]
    # first byte is filter byte
    pixels = row[1:]
    for x in range(w):
        p = pixels[x*bytes_per_pixel : (x+1)*bytes_per_pixel]
        # check if not black (r+g+b > 20)
        if sum(p[:3]) > 20:
            if x < min_x: min_x = x
            if x > max_x: max_x = x
            if y < min_y: min_y = y
            if y > max_y: max_y = y

print(f"Non-black pixel bounding box: X=[{min_x}, {max_x}], Y=[{min_y}, {max_y}]")
print(f"Width of content: {max_x - min_x + 1}, Height of content: {max_y - min_y + 1}")
