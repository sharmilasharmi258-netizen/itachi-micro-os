import os
import zipfile
import shutil

src_dir = r"c:\Users\sharm\Downloads\micro os"
uploads_dir = r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\browser_sandbox\uploads"
os.makedirs(uploads_dir, exist_ok=True)

zip_path = os.path.join(uploads_dir, "itachi-micro-os.zip")

# Files to exclude from zip (temporary backups or huge deb files)
exclude_dirs = {".git", "target", "slax_backup", "__pycache__"}
exclude_exts = {".iso", ".vmdk", ".vdi", ".deb"}

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(src_dir):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in exclude_exts:
                continue
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, src_dir)
            zipf.write(full_path, rel_path)

print(f"Created {zip_path}: {os.path.getsize(zip_path)} bytes")

# Also copy README.md directly
readme_src = os.path.join(src_dir, "README.md")
readme_dst = os.path.join(uploads_dir, "README.md")
shutil.copy2(readme_src, readme_dst)
print(f"Copied README.md to uploads: {os.path.getsize(readme_dst)} bytes")
