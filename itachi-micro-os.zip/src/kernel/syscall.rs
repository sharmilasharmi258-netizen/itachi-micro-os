//! System Interface & Syscall Subsystem (Layer 9 & Specialization Track D)
//!
//! Provides the controlled user-to-kernel transition boundary, system call
//! dispatching, and kernel services abstraction.

use crate::kinfo;
use crate::task::TaskId;

/// System Call Identifiers
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SyscallId {
    Yield = 1,
    Spawn = 2,
    Exit = 3,
    Print = 4,
    GetUptime = 5,
    AllocFrame = 6,
}

/// System Call Result
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SyscallResult {
    Success(u64),
    Error(&'static str),
}

/// Kernel Syscall Dispatcher
pub struct SyscallDispatcher;

impl SyscallDispatcher {
    /// Dispatch a system call from a user task context
    pub fn dispatch(calling_task: TaskId, syscall: SyscallId, arg1: u64, arg2: u64) -> SyscallResult {
        kinfo!(
            "SYS",
            "Transition: User [{}] -> Kernel Syscall {:?} (arg1: 0x{:X}, arg2: 0x{:X})",
            calling_task,
            syscall,
            arg1,
            arg2
        );

        match syscall {
            SyscallId::Yield => {
                kinfo!("SYS", "Task {} voluntarily yields CPU", calling_task);
                SyscallResult::Success(0)
            }
            SyscallId::Spawn => {
                kinfo!("SYS", "Task {} requested spawn of new task priority {}", calling_task, arg1);
                SyscallResult::Success(arg1 + 100) // Return simulated PID
            }
            SyscallId::Exit => {
                kinfo!("SYS", "Task {} requested self-termination with exit code {}", calling_task, arg1);
                SyscallResult::Success(arg1)
            }
            SyscallId::Print => {
                kinfo!("SYS", "Task {} printed message buffer length {}", calling_task, arg1);
                SyscallResult::Success(arg1)
            }
            SyscallId::GetUptime => {
                SyscallResult::Success(arg1 * 10)
            }
            SyscallId::AllocFrame => {
                kinfo!("SYS", "Task {} requested memory allocation of {} bytes", calling_task, arg1);
                SyscallResult::Success(0x2000_0000)
            }
        }
    }
}
