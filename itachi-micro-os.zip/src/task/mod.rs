//! Task Representation Subsystem (Layer 3)
//!
//! Provides the core Task Control Block (TCB), process states, register context,
//! and performance tracking metrics required by CA-6.

use std::fmt;

/// Unique Task Identifier
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct TaskId(pub usize);

impl fmt::Display for TaskId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "PID-{}", self.0)
    }
}

/// Task Execution States (Layer 3)
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TaskState {
    Ready,
    Running,
    Blocked,
    Terminated,
}

impl fmt::Display for TaskState {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TaskState::Ready => write!(f, "READY"),
            TaskState::Running => write!(f, "RUNNING"),
            TaskState::Blocked => write!(f, "BLOCKED"),
            TaskState::Terminated => write!(f, "TERMINATED"),
        }
    }
}

/// Simulated Hardware Register Context for Task Switching
#[derive(Debug, Clone, Default)]
pub struct TaskContext {
    pub instruction_pointer: usize,
    pub stack_pointer: usize,
    pub registers: [u64; 8], // R0 through R7
    pub flags: u64,
}

/// Performance and Accounting Metrics for evaluation (CA-6 Sections 17 & 18)
#[derive(Debug, Clone)]
pub struct TaskMetrics {
    pub arrival_tick: u64,
    pub burst_ticks: u64,
    pub remaining_ticks: u64,
    pub first_scheduled_tick: Option<u64>,
    pub completion_tick: Option<u64>,
    pub total_wait_ticks: u64,
    pub context_switch_count: u64,
}

impl TaskMetrics {
    pub fn new(arrival_tick: u64, burst_ticks: u64) -> Self {
        Self {
            arrival_tick,
            burst_ticks,
            remaining_ticks: burst_ticks,
            first_scheduled_tick: None,
            completion_tick: None,
            total_wait_ticks: 0,
            context_switch_count: 0,
        }
    }

    /// Calculate Turnaround Time: Completion Time - Arrival Time
    pub fn turnaround_time(&self) -> Option<u64> {
        self.completion_tick.map(|end| end.saturating_sub(self.arrival_tick))
    }

    /// Calculate Response Time: First Scheduled Time - Arrival Time
    pub fn response_time(&self) -> Option<u64> {
        self.first_scheduled_tick.map(|start| start.saturating_sub(self.arrival_tick))
    }

    /// Calculate Waiting Time: Turnaround Time - Burst Time
    pub fn waiting_time(&self) -> Option<u64> {
        self.turnaround_time().map(|tt| tt.saturating_sub(self.burst_ticks))
    }
}

/// Task Control Block (TCB)
#[derive(Debug, Clone)]
pub struct Task {
    pub id: TaskId,
    pub name: String,
    pub state: TaskState,
    pub priority: u8, // 0 = Highest, 255 = Lowest
    pub context: TaskContext,
    pub stack: Vec<u8>,
    pub metrics: TaskMetrics,
}

impl Task {
    pub fn new(id: usize, name: impl Into<String>, priority: u8, burst_ticks: u64, arrival_tick: u64) -> Self {
        const DEFAULT_STACK_SIZE: usize = 4096; // 4 KB stack per task
        let stack = vec![0u8; DEFAULT_STACK_SIZE];
        let stack_top = stack.as_ptr() as usize + DEFAULT_STACK_SIZE;

        Self {
            id: TaskId(id),
            name: name.into(),
            state: TaskState::Ready,
            priority,
            context: TaskContext {
                instruction_pointer: 0x1000 + (id * 0x100),
                stack_pointer: stack_top,
                registers: [0; 8],
                flags: 0x202, // IF (Interrupt Flag) enabled
            },
            stack,
            metrics: TaskMetrics::new(arrival_tick, burst_ticks),
        }
    }

    pub fn is_completed(&self) -> bool {
        self.metrics.remaining_ticks == 0
    }
}
