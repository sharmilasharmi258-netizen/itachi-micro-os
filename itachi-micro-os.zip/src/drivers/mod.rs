//! Drivers Subsystem: Console, Serial, and Display Abstractions
//!
//! Provides hardware-independent terminal and console primitives with
//! ANSI formatting, structured color output, and VGA text-mode abstractions.

use std::fmt;

/// ANSI Color Codes for Kernel Console output
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Color {
    Reset,
    Bold,
    Red,
    Green,
    Yellow,
    Blue,
    Magenta,
    Cyan,
    White,
    BrightRed,
    BrightGreen,
    BrightYellow,
    BrightBlue,
    BrightMagenta,
    BrightCyan,
    BrightWhite,
}

impl Color {
    pub fn as_ansi(&self) -> &'static str {
        match self {
            Color::Reset => "\x1b[0m",
            Color::Bold => "\x1b[1m",
            Color::Red => "\x1b[31m",
            Color::Green => "\x1b[32m",
            Color::Yellow => "\x1b[33m",
            Color::Blue => "\x1b[34m",
            Color::Magenta => "\x1b[35m",
            Color::Cyan => "\x1b[36m",
            Color::White => "\x1b[37m",
            Color::BrightRed => "\x1b[91m",
            Color::BrightGreen => "\x1b[92m",
            Color::BrightYellow => "\x1b[93m",
            Color::BrightBlue => "\x1b[94m",
            Color::BrightMagenta => "\x1b[95m",
            Color::BrightCyan => "\x1b[96m",
            Color::BrightWhite => "\x1b[97m",
        }
    }
}

/// Simulated VGA / Serial Console Driver
pub struct Console;

impl Console {
    /// Print a message with a specific color
    pub fn print_colored(color: Color, message: &str) {
        print!("{}{}{}", color.as_ansi(), message, Color::Reset.as_ansi());
    }

    /// Print a line with a specific color
    pub fn println_colored(color: Color, message: &str) {
        println!("{}{}{}", color.as_ansi(), message, Color::Reset.as_ansi());
    }

    /// Clear the console screen
    pub fn clear_screen() {
        print!("\x1b[2J\x1b[H");
    }

    /// Print horizontal separator rule
    pub fn print_separator(title: &str) {
        println!(
            "{}{:=^80}{}",
            Color::Cyan.as_ansi(),
            format!(" [ {} ] ", title),
            Color::Reset.as_ansi()
        );
    }
}

impl fmt::Write for Console {
    fn write_str(&mut self, s: &str) -> fmt::Result {
        print!("{}", s);
        Ok(())
    }
}
