//! Timer Subsystem: Periodic Interrupts & Hardware Clock Abstraction (Layer 6)
//!
//! Provides the periodic timer mechanism that triggers CPU scheduling decisions,
//! drives preemptive time-slicing, and maintains system uptime.

use crate::kinfo;

/// System Timer Configuration and State
pub struct SystemTimer {
    ticks: u64,
    frequency_hz: u64,
}

impl SystemTimer {
    pub fn new(frequency_hz: u64) -> Self {
        kinfo!("TIMER", "Layer 6: Initialized Hardware System Timer at {} Hz", frequency_hz);
        Self {
            ticks: 0,
            frequency_hz,
        }
    }

    /// Advance the timer by one tick (simulating an IRQ0 interrupt)
    pub fn tick(&mut self) -> u64 {
        self.ticks += 1;
        self.ticks
    }

    /// Retrieve current elapsed ticks
    pub fn current_ticks(&self) -> u64 {
        self.ticks
    }

    /// Retrieve uptime in milliseconds
    pub fn uptime_ms(&self) -> f64 {
        (self.ticks as f64 / self.frequency_hz as f64) * 1000.0
    }
}
