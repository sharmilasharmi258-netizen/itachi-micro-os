//! Memory Management Subsystem: Allocators, Frame Management & Paging (Layer 8)
//!
//! Implements:
//! - Layer 8: Bump Allocator (fast linear contiguous allocations)
//! - Frame Allocator (4KB page-frame bitmap tracker)
//! - Memory bounds checking and failure handling (satisfying TC5)
//! - Allocation performance and fragmentation statistics

use crate::kinfo;

pub const PAGE_SIZE: usize = 4096; // 4 KB physical frame size

/// Layer 8: Bump Allocator (Linear Allocator)
pub struct BumpAllocator {
    heap_start: usize,
    heap_end: usize,
    next: usize,
    allocations: usize,
}

impl BumpAllocator {
    pub fn new(heap_start: usize, size: usize) -> Self {
        kinfo!("MEM", "Layer 8: Initialized Bump Allocator [Base: 0x{:X}, Capacity: {} KB]", heap_start, size / 1024);
        Self {
            heap_start,
            heap_end: heap_start + size,
            next: heap_start,
            allocations: 0,
        }
    }

    /// Allocate a contiguous memory block with alignment
    pub fn allocate(&mut self, size: usize, align: usize) -> Result<usize, &'static str> {
        let alloc_start = (self.next + align - 1) & !(align - 1);
        let alloc_end = alloc_start.checked_add(size).ok_or("Overflow during allocation calculation")?;

        if alloc_end > self.heap_end {
            return Err("OUT_OF_MEMORY: Allocation exceeds bump allocator heap boundary");
        }

        self.next = alloc_end;
        self.allocations += 1;
        Ok(alloc_start)
    }

    pub fn used_bytes(&self) -> usize {
        self.next - self.heap_start
    }

    pub fn available_bytes(&self) -> usize {
        self.heap_end - self.next
    }

    pub fn allocation_count(&self) -> usize {
        self.allocations
    }

    /// Reset the bump allocator
    pub fn reset(&mut self) {
        self.next = self.heap_start;
        self.allocations = 0;
    }
}

/// Physical Page Frame Allocator (Bitmap-backed)
pub struct FrameAllocator {
    total_frames: usize,
    bitmap: Vec<u64>,
    allocated_frames: usize,
}

impl FrameAllocator {
    pub fn new(total_frames: usize) -> Self {
        let num_u64 = (total_frames + 63) / 64;
        kinfo!("MEM", "Layer 8: Initialized Frame Allocator [Total Frames: {}, Managed Memory: {} MB]", total_frames, (total_frames * PAGE_SIZE) / (1024 * 1024));
        Self {
            total_frames,
            bitmap: vec![0u64; num_u64],
            allocated_frames: 0,
        }
    }

    /// Allocate the first free 4KB physical frame
    pub fn allocate_frame(&mut self) -> Result<usize, &'static str> {
        for (word_idx, word) in self.bitmap.iter_mut().enumerate() {
            if *word != u64::MAX {
                // Found a word with at least one free bit
                let bit_idx = word.trailing_ones() as usize;
                let frame_idx = (word_idx * 64) + bit_idx;

                if frame_idx >= self.total_frames {
                    break;
                }

                *word |= 1u64 << bit_idx;
                self.allocated_frames += 1;
                return Ok(frame_idx);
            }
        }
        Err("OUT_OF_FRAMES: Physical memory frames exhausted")
    }

    /// Deallocate a physical frame
    pub fn deallocate_frame(&mut self, frame_idx: usize) -> Result<(), &'static str> {
        if frame_idx >= self.total_frames {
            return Err("INVALID_FRAME: Frame index out of bounds");
        }

        let word_idx = frame_idx / 64;
        let bit_idx = frame_idx % 64;
        let mask = 1u64 << bit_idx;

        if (self.bitmap[word_idx] & mask) == 0 {
            return Err("DOUBLE_FREE: Attempted to free an unallocated frame");
        }

        self.bitmap[word_idx] &= !mask;
        self.allocated_frames = self.allocated_frames.saturating_sub(1);
        Ok(())
    }

    pub fn allocated_count(&self) -> usize {
        self.allocated_frames
    }

    pub fn free_count(&self) -> usize {
        self.total_frames.saturating_sub(self.allocated_frames)
    }
}
