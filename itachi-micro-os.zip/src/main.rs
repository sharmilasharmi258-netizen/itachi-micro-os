//! Micro-OS: Minimal Educational Operating System in Rust
//! Course: Operating Systems | Continuous Assessment 6 (15 Marks)
//!
//! Orchestrates the 10-Layer Architecture:
//! - Layer 1: Boot sequence & CPU initialization
//! - Layer 2: Kernel console & structured diagnostics
//! - Layer 3: Task representation & Task Control Blocks (TCBs)
//! - Layer 4: Kernel Ready Queue
//! - Layer 5: Round Robin CPU Scheduler
//! - Layer 6: Timer-driven periodic scheduling & preemption
//! - Layer 7: Kernel synchronization (Spinlock & Critical Sections)
//! - Layer 8: Memory management (Bump & Frame Allocator)
//! - Layer 9: System Call Interface (User/Kernel transition)
//! - Layer 10: Integrated Micro-OS Lifecycle Execution
//! - Specialization Track A: Dynamic Priority Scheduling with Aging

pub mod drivers;
pub mod kernel;
pub mod memory;
pub mod scheduler;
pub mod sync;
pub mod task;
pub mod timer;

use std::env;
use drivers::Console;
use kernel::boot_sequence;
use memory::{BumpAllocator, FrameAllocator};
use scheduler::{Scheduler, SchedulingPolicy};
use sync::run_synchronization_demonstration;
use task::Task;
use timer::SystemTimer;

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.contains(&"--help".to_string()) || args.contains(&"-h".to_string()) {
        print_usage();
        return;
    }

    if args.contains(&"--tc".to_string()) {
        let tc_num = args.iter().position(|r| r == "--tc")
            .and_then(|idx| args.get(idx + 1))
            .and_then(|s| s.parse::<usize>().ok())
            .unwrap_or(1);
        run_test_case(tc_num);
        return;
    }

    if args.contains(&"--all-tests".to_string()) {
        run_all_test_cases();
        return;
    }

    // Default: Run Layer 10 Integrated Micro-OS Demonstration
    run_integrated_demonstration(SchedulingPolicy::RoundRobin);
}

fn print_usage() {
    println!("Usage: micro_os [OPTIONS]");
    println!();
    println!("Options:");
    println!("  --demo            Run the full Layer 10 Integrated Micro-OS Lifecycle (Default)");
    println!("  --tc <1-6>        Run specific CA-6 required test case (TC1 to TC6)");
    println!("  --all-tests       Run all CA-6 validation test cases sequentially");
    println!("  --help, -h        Print this help message");
}

/// Layer 10: Integrated Micro-OS Execution Demonstration
pub fn run_integrated_demonstration(policy: SchedulingPolicy) {
    // 1. Layer 1 & 2: Boot & Diagnostics
    boot_sequence();

    // 2. Layer 8: Initialize Memory Subsystem
    Console::print_separator("LAYER 8: MEMORY SUBSYSTEM INITIALIZATION");
    let mut bump_alloc = BumpAllocator::new(0x1000_0000, 64 * 1024); // 64 KB heap
    let mut frame_alloc = FrameAllocator::new(1024); // 4 MB managed memory (1024 * 4KB frames)

    let buf_addr = bump_alloc.allocate(256, 8).expect("Failed to allocate kernel buffer");
    kinfo!("MEM", "Allocated 256-byte kernel buffer at physical address: 0x{:X}", buf_addr);
    let frame1 = frame_alloc.allocate_frame().expect("Failed to allocate physical frame");
    kinfo!("MEM", "Allocated physical page frame: Frame #{} (Address: 0x{:X})", frame1, frame1 * 4096);

    // 3. Layer 7: Initialize Synchronization Subsystem
    Console::print_separator("LAYER 7: KERNEL SYNCHRONIZATION & CONCURRENCY");
    let sync_ok = run_synchronization_demonstration();
    assert!(sync_ok, "Synchronization test must pass");

    // 4. Layer 9: System Interface Check
    Console::print_separator("LAYER 9: SYSTEM INTERFACE / USER-KERNEL BOUNDARY");
    kernel::syscall::SyscallDispatcher::dispatch(
        task::TaskId(1),
        kernel::syscall::SyscallId::Print,
        42,
        0,
    );

    // 5. Layer 3, 4, 5, 6: Tasks, Ready Queue, Scheduler & Timer
    Console::print_separator("LAYERS 3-6: INTEGRATED CPU SCHEDULING (ROUND ROBIN)");
    let time_quantum = 2; // 2 ticks per time slice
    let mut scheduler = Scheduler::new(policy, time_quantum);
    let mut timer = SystemTimer::new(100); // 100 Hz timer

    // Workload creation (Diverse realistic OS tasks)
    scheduler.add_task(Task::new(1, "WiFi_Telemetry_Daemon", 1, 6, 0));
    scheduler.add_task(Task::new(2, "Apt_Package_Resolver", 2, 4, 0));
    scheduler.add_task(Task::new(3, "Snapstore_Service", 3, 5, 0));
    scheduler.add_task(Task::new(4, "Hardware_Display_Server", 0, 3, 0));

    kinfo!("SCHED", "Starting CPU Scheduling loop with Quantum = {} ticks...", time_quantum);

    let max_ticks = 100;
    while !scheduler.is_all_completed() && timer.current_ticks() < max_ticks {
        let current_tick = timer.tick();
        scheduler.tick(current_tick);
    }

    let total_ticks = timer.current_ticks();
    kinfo!("SCHED", "All tasks completed successfully in {} ticks!", total_ticks);

    // 6. Performance Summary & Evidence (CA-6 Sections 17 & 18)
    Console::print_separator("PERFORMANCE EVALUATION & EVIDENCE SUMMARY");
    let summary = scheduler.compute_summary(total_ticks);

    println!("{:<25}: {}", "Total Completed Tasks", summary.completed_tasks);
    println!("{:<25}: {} ticks", "Total Execution Time", summary.total_ticks);
    println!("{:<25}: {}", "Total Context Switches", summary.total_context_switches);
    println!("{:<25}: {:.2} ticks", "Average Waiting Time", summary.avg_waiting_time);
    println!("{:<25}: {:.2} ticks", "Average Turnaround Time", summary.avg_turnaround_time);
    println!("{:<25}: {:.2} ticks", "Average Response Time", summary.avg_response_time);
    println!("{:<25}: {:.2}%", "CPU Utilization", summary.cpu_utilization);
    println!("{:<25}: {:.4} tasks/tick", "CPU Throughput", summary.throughput);

    // Export trace CSV for Python analysis
    let trace_path = "traces/scheduler_trace.csv";
    if let Err(e) = scheduler.export_trace_csv(trace_path) {
        kerror!("SYS", "Failed to export CSV trace: {}", e);
    } else {
        kinfo!("SYS", "Exported execution trace to: {}", trace_path);
    }

    Console::print_separator("MICRO-OS DEMONSTRATION COMPLETE: READY FOR VIVA DEFENCE");
}

/// Execute a specific CA-6 validation test case (Section 16)
pub fn run_test_case(tc_number: usize) {
    match tc_number {
        1 => test_case_1(),
        2 => test_case_2(),
        3 => test_case_3(),
        4 => test_case_4(),
        5 => test_case_5(),
        6 => test_case_6(),
        _ => eprintln!("Invalid test case number: {}. Valid range is 1-6.", tc_number),
    }
}

pub fn run_all_test_cases() {
    Console::print_separator("CA-6 SYSTEMATIC TEST SUITE EXECUTION (TC1 - TC6)");
    test_case_1();
    test_case_2();
    test_case_3();
    test_case_4();
    test_case_5();
    test_case_6();
    Console::print_separator("ALL 6 REQUIRED TEST CASES PASSED SUCCESSFULLY!");
}

/// TC1: Minimum Configuration (Two Tasks)
fn test_case_1() {
    Console::print_separator("TC1: Minimum Configuration (2 Tasks)");
    let mut sched = Scheduler::new(SchedulingPolicy::RoundRobin, 2);
    let mut timer = SystemTimer::new(100);

    sched.add_task(Task::new(1, "Task_Alpha", 1, 4, 0));
    sched.add_task(Task::new(2, "Task_Beta", 1, 4, 0));

    while !sched.is_all_completed() {
        let t = timer.tick();
        sched.tick(t);
    }

    assert_eq!(sched.completed_tasks.len(), 2);
    println!(">>> TC1 PASS: 2 tasks scheduled and completed in alternating Round-Robin order.");
}

/// TC2: Multiple Tasks (4-5 Controlled Tasks)
fn test_case_2() {
    Console::print_separator("TC2: Multiple Tasks (5 Tasks with Varying Bursts)");
    let mut sched = Scheduler::new(SchedulingPolicy::RoundRobin, 2);
    let mut timer = SystemTimer::new(100);

    sched.add_task(Task::new(1, "Worker_1", 1, 5, 0));
    sched.add_task(Task::new(2, "Worker_2", 1, 3, 0));
    sched.add_task(Task::new(3, "Worker_3", 1, 7, 0));
    sched.add_task(Task::new(4, "Worker_4", 1, 2, 0));
    sched.add_task(Task::new(5, "Worker_5", 1, 4, 0));

    while !sched.is_all_completed() {
        let t = timer.tick();
        sched.tick(t);
    }

    assert_eq!(sched.completed_tasks.len(), 5);
    println!(">>> TC2 PASS: 5 tasks completed correctly without starvation.");
}

/// TC3: Boundary Case (Quantum = 1 tick, maximum switching)
fn test_case_3() {
    Console::print_separator("TC3: Boundary Case (Quantum = 1 Tick)");
    let mut sched = Scheduler::new(SchedulingPolicy::RoundRobin, 1);
    let mut timer = SystemTimer::new(100);

    sched.add_task(Task::new(1, "Bound_A", 1, 3, 0));
    sched.add_task(Task::new(2, "Bound_B", 1, 3, 0));

    while !sched.is_all_completed() {
        let t = timer.tick();
        sched.tick(t);
    }

    assert!(sched.total_context_switches >= 5);
    println!(">>> TC3 PASS: Boundary quantum=1 produced fine-grained interleaving (switches: {}).", sched.total_context_switches);
}

/// TC4: Stress Case (Large Batch of Tasks)
fn test_case_4() {
    Console::print_separator("TC4: Stress Case (20 Rapid Concurrent Tasks)");
    let mut sched = Scheduler::new(SchedulingPolicy::RoundRobin, 2);
    let mut timer = SystemTimer::new(100);

    for i in 1..=20 {
        sched.add_task(Task::new(i, format!("Stress_Task_{}", i), (i % 5) as u8, 3, 0));
    }

    while !sched.is_all_completed() {
        let t = timer.tick();
        sched.tick(t);
    }

    assert_eq!(sched.completed_tasks.len(), 20);
    println!(">>> TC4 PASS: Handled 20 tasks under heavy queue pressure with 100% completion.");
}

/// TC5: Failure Case (Out of Memory & Invalid Frame Freeing)
fn test_case_5() {
    Console::print_separator("TC5: Failure Case (Controlled Out-of-Memory & Double-Free)");
    let mut bump = BumpAllocator::new(0x1000, 1024); // Only 1 KB
    let mut frame_alloc = FrameAllocator::new(16); // Only 16 frames

    // Test 1: Exceed bump heap boundary
    let err1 = bump.allocate(2048, 8);
    assert!(err1.is_err(), "Expected OOM error for over-allocation");
    println!("  [OK] Caught expected failure: {:?}", err1.unwrap_err());

    // Test 2: Double free on page frame
    let f0 = frame_alloc.allocate_frame().unwrap();
    frame_alloc.deallocate_frame(f0).unwrap();
    let err2 = frame_alloc.deallocate_frame(f0);
    assert!(err2.is_err(), "Expected double-free error");
    println!("  [OK] Caught expected failure: {:?}", err2.unwrap_err());

    println!(">>> TC5 PASS: Kernel robustly handled memory boundary and double-free violations.");
}

/// TC6: Repeatability Case (Identical trace across runs)
fn test_case_6() {
    Console::print_separator("TC6: Repeatability & Determinism Verification");

    let run_workload = || {
        let mut sched = Scheduler::new(SchedulingPolicy::RoundRobin, 2);
        let mut timer = SystemTimer::new(100);
        sched.add_task(Task::new(1, "Rep_1", 1, 4, 0));
        sched.add_task(Task::new(2, "Rep_2", 1, 3, 0));
        while !sched.is_all_completed() {
            let t = timer.tick();
            sched.tick(t);
        }
        (sched.total_context_switches, sched.completed_tasks.len())
    };

    let (sw1, count1) = run_workload();
    let (sw2, count2) = run_workload();

    assert_eq!(sw1, sw2);
    assert_eq!(count1, count2);
    println!(">>> TC6 PASS: Exactly identical execution metrics across repeated runs (Switches: {}, Tasks: {}).", sw1, count1);
}
