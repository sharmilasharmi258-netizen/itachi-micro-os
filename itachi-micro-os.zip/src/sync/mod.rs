//! Synchronization Subsystem: Spinlocks, Mutex Primitives & Critical Sections (Layer 7)
//!
//! Implements:
//! - Spinlock<T> with atomic test-and-set operations
//! - Safe RAII SpinlockGuard<T> with automatic unlock on drop
//! - Lock contention statistics
//! - Shared resource demonstration (Race Condition vs Protected Execution)
//! - Explicit adherence to CA-6 unsafe Rust policy (Section 26)

use std::cell::UnsafeCell;
use std::ops::{Deref, DerefMut};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use crate::kinfo;

/// High-performance Spinlock primitive for kernel critical sections (Layer 7)
pub struct Spinlock<T> {
    locked: AtomicBool,
    data: UnsafeCell<T>,
    // Performance & contention accounting
    acquisitions: AtomicU64,
    spins: AtomicU64,
}

// Safety: Spinlock provides mutual exclusion across threads/tasks
unsafe impl<T: Send> Sync for Spinlock<T> {}
unsafe impl<T: Send> Send for Spinlock<T> {}

impl<T> Spinlock<T> {
    pub const fn new(data: T) -> Self {
        Self {
            locked: AtomicBool::new(false),
            data: UnsafeCell::new(data),
            acquisitions: AtomicU64::new(0),
            spins: AtomicU64::new(0),
        }
    }

    /// Acquire the spinlock, busy-waiting until lock is free
    pub fn lock(&self) -> SpinlockGuard<'_, T> {
        let mut spin_count = 0;

        // Test-and-set loop with Relaxed spin followed by Acquire on transition
        while self
            .locked
            .compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed)
            .is_err()
        {
            spin_count += 1;
            std::hint::spin_loop();
        }

        self.acquisitions.fetch_add(1, Ordering::Relaxed);
        self.spins.fetch_add(spin_count, Ordering::Relaxed);

        SpinlockGuard { lock: self }
    }

    /// Try to acquire the spinlock without blocking
    pub fn try_lock(&self) -> Option<SpinlockGuard<'_, T>> {
        if self
            .locked
            .compare_exchange(false, true, Ordering::Acquire, Ordering::Relaxed)
            .is_ok()
        {
            self.acquisitions.fetch_add(1, Ordering::Relaxed);
            Some(SpinlockGuard { lock: self })
        } else {
            None
        }
    }

    /// Retrieve total acquisition count
    pub fn acquisitions(&self) -> u64 {
        self.acquisitions.load(Ordering::Relaxed)
    }

    /// Retrieve total spin count (measure of lock contention)
    pub fn total_spins(&self) -> u64 {
        self.spins.load(Ordering::Relaxed)
    }
}

/// RAII Guard that releases the Spinlock when dropped
pub struct SpinlockGuard<'a, T> {
    lock: &'a Spinlock<T>,
}

impl<T> Deref for SpinlockGuard<'_, T> {
    type Target = T;

    fn deref(&self) -> &Self::Target {
        // SAFETY: The lock is held exclusively by this guard (AtomicBool is true).
        // No concurrent mutable access can occur.
        unsafe { &*self.lock.data.get() }
    }
}

impl<T> DerefMut for SpinlockGuard<'_, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        // SAFETY: The lock is held exclusively by this guard (AtomicBool is true).
        // No concurrent access can occur while this mutable reference exists.
        unsafe { &mut *self.lock.data.get() }
    }
}

impl<T> Drop for SpinlockGuard<'_, T> {
    fn drop(&mut self) {
        // Release the lock with Release ordering so preceding memory writes are visible
        self.lock.locked.store(false, Ordering::Release);
    }
}

/// Demonstrate Shared-Resource Problem -> Synchronization -> Corrected Execution (CA-6 Layer 7)
pub fn run_synchronization_demonstration() -> bool {
    kinfo!("SYNC", "Layer 7: Starting Kernel Synchronization & Concurrency Demonstration...");

    const ITERATIONS: usize = 10_000;
    let shared_counter = Spinlock::new(0usize);

    std::thread::scope(|s| {
        let t1 = s.spawn(|| {
            for _ in 0..ITERATIONS {
                let mut guard = shared_counter.lock();
                *guard += 1;
            }
        });

        let t2 = s.spawn(|| {
            for _ in 0..ITERATIONS {
                let mut guard = shared_counter.lock();
                *guard += 1;
            }
        });

        t1.join().unwrap();
        t2.join().unwrap();
    });

    let final_val = *shared_counter.lock();
    let expected = ITERATIONS * 2;
    let success = final_val == expected;

    kinfo!(
        "SYNC",
        "Verification: Final Counter = {} | Expected = {} | Result: {}",
        final_val,
        expected,
        if success { "PASS (Zero Race Conditions)" } else { "FAIL (Data Race Detected)" }
    );
    kinfo!(
        "SYNC",
        "Lock Contention Metrics: Acquisitions = {}, Total Busy Spins = {}",
        shared_counter.acquisitions(),
        shared_counter.total_spins()
    );

    success
}
