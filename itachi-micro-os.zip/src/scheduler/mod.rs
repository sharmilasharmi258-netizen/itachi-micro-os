//! Scheduler Subsystem: Ready Queue, Round Robin & Priority Scheduling
//!
//! Implements:
//! - Layer 4: Ready Queue management
//! - Layer 5: Round Robin time-slice scheduling
//! - Specialization Track A: Priority Scheduling with Aging (prevents starvation)
//! - Detailed scheduler trace logging for Python analysis (CA-6 Section 19)

use std::collections::VecDeque;
use std::fs::File;
use std::io::Write;

use crate::kinfo;
use crate::task::{Task, TaskId, TaskState};

/// Scheduling Policy Options
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SchedulingPolicy {
    RoundRobin,
    PriorityWithAging,
}

/// Reason for a Context Switch
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SwitchReason {
    QuantumExpired,
    TaskCompleted,
    VoluntaryYield,
    PriorityPreemption,
    InitialDispatch,
}

impl SwitchReason {
    pub fn as_str(&self) -> &'static str {
        match self {
            SwitchReason::QuantumExpired => "QUANTUM_EXPIRED",
            SwitchReason::TaskCompleted => "TASK_COMPLETED",
            SwitchReason::VoluntaryYield => "VOLUNTARY_YIELD",
            SwitchReason::PriorityPreemption => "PRIORITY_PREEMPTION",
            SwitchReason::InitialDispatch => "INITIAL_DISPATCH",
        }
    }
}

/// Structured record of a scheduling event for trace logging and CSV export
#[derive(Debug, Clone)]
pub struct SchedulerTraceEvent {
    pub tick: u64,
    pub previous_task: Option<TaskId>,
    pub next_task: TaskId,
    pub reason: SwitchReason,
    pub remaining_burst: u64,
    pub ready_queue_length: usize,
}

/// Layer 4: Kernel Ready Queue
#[derive(Debug, Default)]
pub struct ReadyQueue {
    tasks: VecDeque<Task>,
}

impl ReadyQueue {
    pub fn new() -> Self {
        Self {
            tasks: VecDeque::new(),
        }
    }

    pub fn enqueue(&mut self, mut task: Task) {
        task.state = TaskState::Ready;
        self.tasks.push_back(task);
    }

    pub fn dequeue(&mut self) -> Option<Task> {
        self.tasks.pop_front()
    }

    pub fn len(&self) -> usize {
        self.tasks.len()
    }

    pub fn is_empty(&self) -> bool {
        self.tasks.is_empty()
    }

    pub fn iter(&self) -> impl Iterator<Item = &Task> {
        self.tasks.iter()
    }

    /// Select highest priority task (lower numeric value = higher priority)
    pub fn dequeue_highest_priority(&mut self) -> Option<Task> {
        if self.tasks.is_empty() {
            return None;
        }

        let mut best_idx = 0;
        let mut highest_prio = self.tasks[0].priority;

        for (i, t) in self.tasks.iter().enumerate().skip(1) {
            if t.priority < highest_prio {
                highest_prio = t.priority;
                best_idx = i;
            }
        }

        self.tasks.remove(best_idx)
    }

    /// Apply priority aging: Tasks waiting in the queue gain priority over time
    pub fn apply_aging(&mut self, aging_interval_ticks: u64, current_tick: u64) {
        for task in self.tasks.iter_mut() {
            let wait_time = current_tick.saturating_sub(task.metrics.arrival_tick);
            if wait_time > 0 && wait_time % aging_interval_ticks == 0 && task.priority > 0 {
                task.priority = task.priority.saturating_sub(1);
            }
        }
    }
}

/// System Summary Metrics
#[derive(Debug, Default, Clone)]
pub struct SchedulerSummary {
    pub total_tasks: usize,
    pub completed_tasks: usize,
    pub total_ticks: u64,
    pub total_context_switches: u64,
    pub avg_waiting_time: f64,
    pub avg_turnaround_time: f64,
    pub avg_response_time: f64,
    pub cpu_utilization: f64,
    pub throughput: f64,
}

/// Central Micro-OS Scheduler (Layers 4, 5, 6 & Specialization Track A)
pub struct Scheduler {
    pub policy: SchedulingPolicy,
    pub ready_queue: ReadyQueue,
    pub current_task: Option<Task>,
    pub completed_tasks: Vec<Task>,
    pub time_quantum: u64,
    pub current_quantum_remaining: u64,
    pub total_context_switches: u64,
    pub trace_events: Vec<SchedulerTraceEvent>,
}

impl Scheduler {
    pub fn new(policy: SchedulingPolicy, time_quantum: u64) -> Self {
        Self {
            policy,
            ready_queue: ReadyQueue::new(),
            current_task: None,
            completed_tasks: Vec::new(),
            time_quantum,
            current_quantum_remaining: time_quantum,
            total_context_switches: 0,
            trace_events: Vec::new(),
        }
    }

    /// Add a new task to the scheduler ready queue
    pub fn add_task(&mut self, task: Task) {
        kinfo!("SCHED", "Enqueued new task: {} [Priority: {}, Burst: {} ticks]", task.name, task.priority, task.metrics.burst_ticks);
        self.ready_queue.enqueue(task);
    }

    /// Primary scheduling tick logic called on every timer interrupt
    pub fn tick(&mut self, current_tick: u64) -> Option<TaskId> {
        // Step 1: Update waiting time for all tasks in ready queue
        for task in self.ready_queue.tasks.iter_mut() {
            task.metrics.total_wait_ticks += 1;
        }

        // Step 2: Apply aging if using Priority Scheduling
        if self.policy == SchedulingPolicy::PriorityWithAging {
            self.ready_queue.apply_aging(4, current_tick);
        }

        // Step 3: Handle currently running task
        if let Some(mut current) = self.current_task.take() {
            current.metrics.remaining_ticks = current.metrics.remaining_ticks.saturating_sub(1);
            self.current_quantum_remaining = self.current_quantum_remaining.saturating_sub(1);

            if current.is_completed() {
                // Task has finished execution
                current.state = TaskState::Terminated;
                current.metrics.completion_tick = Some(current_tick);
                let pid = current.id;
                let name = current.name.clone();
                let tt = current.metrics.turnaround_time().unwrap_or(0);
                let wt = current.metrics.waiting_time().unwrap_or(0);

                kinfo!("TASK", "{} ({}) TERMINATED at tick {}. [Turnaround: {} ticks, Wait: {} ticks]", name, pid, current_tick, tt, wt);
                self.completed_tasks.push(current);

                // Dispatch next task
                self.schedule_next(current_tick, Some(pid), SwitchReason::TaskCompleted);
            } else if self.current_quantum_remaining == 0 {
                // Time quantum expired -> preemption
                current.state = TaskState::Ready;
                let pid = current.id;
                self.ready_queue.enqueue(current);

                kinfo!("SCHED", "Quantum expired for {}. Context switching...", pid);
                self.schedule_next(current_tick, Some(pid), SwitchReason::QuantumExpired);
            } else {
                // Keep running the current task
                self.current_task = Some(current);
            }
        } else {
            // CPU was idle, dispatch next ready task
            self.schedule_next(current_tick, None, SwitchReason::InitialDispatch);
        }

        self.current_task.as_ref().map(|t| t.id)
    }

    /// Select and switch context to the next task
    fn schedule_next(&mut self, current_tick: u64, previous_pid: Option<TaskId>, reason: SwitchReason) {
        let next_task = match self.policy {
            SchedulingPolicy::RoundRobin => self.ready_queue.dequeue(),
            SchedulingPolicy::PriorityWithAging => self.ready_queue.dequeue_highest_priority(),
        };

        if let Some(mut next) = next_task {
            next.state = TaskState::Running;
            if next.metrics.first_scheduled_tick.is_none() {
                next.metrics.first_scheduled_tick = Some(current_tick);
            }
            next.metrics.context_switch_count += 1;
            self.total_context_switches += 1;
            self.current_quantum_remaining = self.time_quantum;

            let next_pid = next.id;
            let rem_burst = next.metrics.remaining_ticks;

            // Log trace event
            self.trace_events.push(SchedulerTraceEvent {
                tick: current_tick,
                previous_task: previous_pid,
                next_task: next_pid,
                reason,
                remaining_burst: rem_burst,
                ready_queue_length: self.ready_queue.len(),
            });

            kinfo!(
                "SCHED",
                "DISPATCH: [{}] -> [{}] (Reason: {}, Remaining Burst: {} ticks, Ready Queue: {})",
                previous_pid.map(|p| p.to_string()).unwrap_or_else(|| "IDLE".into()),
                next_pid,
                reason.as_str(),
                rem_burst,
                self.ready_queue.len()
            );

            self.current_task = Some(next);
        } else {
            self.current_task = None;
        }
    }

    /// Check if all scheduled tasks are finished
    pub fn is_all_completed(&self) -> bool {
        self.current_task.is_none() && self.ready_queue.is_empty()
    }

    /// Compute summary statistics for scientific evaluation (CA-6 Sections 18 & 19)
    pub fn compute_summary(&self, total_ticks: u64) -> SchedulerSummary {
        let completed = &self.completed_tasks;
        let count = completed.len();
        if count == 0 {
            return SchedulerSummary::default();
        }

        let total_wt: u64 = completed.iter().filter_map(|t| t.metrics.waiting_time()).sum();
        let total_tt: u64 = completed.iter().filter_map(|t| t.metrics.turnaround_time()).sum();
        let total_rt: u64 = completed.iter().filter_map(|t| t.metrics.response_time()).sum();

        let avg_wt = total_wt as f64 / count as f64;
        let avg_tt = total_tt as f64 / count as f64;
        let avg_rt = total_rt as f64 / count as f64;
        let throughput = (count as f64) / (total_ticks as f64);

        SchedulerSummary {
            total_tasks: count,
            completed_tasks: count,
            total_ticks,
            total_context_switches: self.total_context_switches,
            avg_waiting_time: avg_wt,
            avg_turnaround_time: avg_tt,
            avg_response_time: avg_rt,
            cpu_utilization: 100.0,
            throughput,
        }
    }

    /// Export execution traces into CSV format for Python analysis scripts
    pub fn export_trace_csv(&self, file_path: &str) -> std::io::Result<()> {
        let mut file = File::create(file_path)?;
        writeln!(file, "tick,previous_task,next_task,reason,remaining_burst,ready_queue_length")?;

        for event in &self.trace_events {
            writeln!(
                file,
                "{},{},{},{},{},{}",
                event.tick,
                event.previous_task.map(|p| p.0.to_string()).unwrap_or_else(|| "NONE".into()),
                event.next_task.0,
                event.reason.as_str(),
                event.remaining_burst,
                event.ready_queue_length
            )?;
        }
        Ok(())
    }
}
