import os

reboot_sh = """#!/bin/bash
# ITACHI MICRO-OS: Safe Unmount & Reboot to Windows
sync
sync
sleep 0.5
if command -v systemctl >/dev/null 2>&1; then
    systemctl --force reboot || systemctl reboot || reboot -f
else
    reboot -f
fi
"""

poweroff_sh = """#!/bin/bash
# ITACHI MICRO-OS: Safe Power Off
sync
sync
sleep 0.5
if command -v systemctl >/dev/null 2>&1; then
    systemctl --force poweroff || systemctl poweroff || poweroff -f
else
    poweroff -f
fi
"""

reboot_desktop = """[Desktop Entry]
Version=1.0
Type=Application
Name=Reboot to Windows
Comment=Safely unmount and reboot back to Windows
Exec=/usr/local/bin/reboot-to-windows
Icon=system-reboot
Terminal=false
Categories=System;
"""

poweroff_desktop = """[Desktop Entry]
Version=1.0
Type=Application
Name=Safely Power Off
Comment=Safely unmount and power off system
Exec=/usr/local/bin/poweroff-system
Icon=system-shutdown
Terminal=false
Categories=System;
"""

rc_local = """#!/bin/bash
chmod +x /usr/local/bin/* 2>/dev/null
chmod +x /root/Desktop/*.desktop 2>/dev/null
chmod +x /usr/share/applications/*.desktop 2>/dev/null
if [ -f /usr/bin/xterm ]; then
    ln -sf /usr/local/bin/x-terminal-emulator /usr/bin/x-terminal-emulator 2>/dev/null
    ln -sf /usr/local/bin/x-terminal-emulator /etc/alternatives/x-terminal-emulator 2>/dev/null
    ln -sf /usr/bin/xterm /usr/local/bin/terminal 2>/dev/null
fi
exit 0
"""

base = r"D:\slax\rootcopy"

# Ensure directories
dirs = [
    os.path.join(base, "usr", "local", "bin"),
    os.path.join(base, "usr", "share", "applications"),
    os.path.join(base, "root", "Desktop"),
    os.path.join(base, "etc", "X11", "Xsession.d"),
]
for d in dirs:
    os.makedirs(d, exist_ok=True)

# Write scripts with LF line endings
def write_file(path, content):
    with open(path, "wb") as f:
        f.write(content.replace("\r\n", "\n").encode("utf-8"))
    print(f"Written: {path}")

write_file(os.path.join(base, "usr", "local", "bin", "reboot-to-windows"), reboot_sh)
write_file(os.path.join(base, "usr", "local", "bin", "poweroff-system"), poweroff_sh)

write_file(os.path.join(base, "root", "Desktop", "reboot-to-windows.desktop"), reboot_desktop)
write_file(os.path.join(base, "usr", "share", "applications", "reboot-to-windows.desktop"), reboot_desktop)

write_file(os.path.join(base, "root", "Desktop", "poweroff.desktop"), poweroff_desktop)
write_file(os.path.join(base, "usr", "share", "applications", "poweroff.desktop"), poweroff_desktop)

write_file(os.path.join(base, "etc", "rc.local"), rc_local)
write_file(os.path.join(base, "etc", "X11", "Xsession.d", "99-itachi-init"), rc_local)

print("ALL_REBOOT_COMPONENTS_VERIFIED_AND_WRITTEN")
