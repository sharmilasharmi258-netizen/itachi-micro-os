import struct
import zlib

with open(r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\itachi_welcome_bootlogo.png", "rb") as f:
    data = f.read()

pos = 8
idat_chunks = []
w, h, depth, color_type = 0, 0, 0, 0
while pos < len(data):
    length, chunk_type = struct.unpack(">I4s", data[pos:pos+8])
    pos += 8
    chunk_data = data[pos:pos+length]
    pos += length + 4
    if chunk_type == b"IHDR":
        w, h, depth, color_type = struct.unpack(">IIBB", chunk_data[:10])
    elif chunk_type == b"IDAT":
        idat_chunks.append(chunk_data)
    elif chunk_type == b"IEND":
        break

raw_idat = zlib.decompress(b"".join(idat_chunks))
bytes_per_pixel = 4 if color_type == 6 else 3
row_size = 1 + w * bytes_per_pixel

min_x, max_x, min_y, max_y = w, 0, h, 0
for y in range(h):
    row = raw_idat[y*row_size : (y+1)*row_size]
    pixels = row[1:]
    for x in range(w):
        p = pixels[x*bytes_per_pixel : (x+1)*bytes_per_pixel]
        if sum(p[:3]) > 20:
            if x < min_x: min_x = x
            if x > max_x: max_x = x
            if y < min_y: min_y = y
            if y > max_y: max_y = y

print(f"itachi_welcome_bootlogo: X=[{min_x}, {max_x}], Y=[{min_y}, {max_y}]")
print(f"Content Width: {max_x - min_x + 1}, Height: {max_y - min_y + 1}")
