Set objShell = CreateObject("Shell.Application")
objShell.ShellExecute "cmd.exe", "/c ""C:\Users\sharm\Downloads\micro os\CLICK_ME_TO_FIX_PENDRIVE.bat""", "", "runas", 1
