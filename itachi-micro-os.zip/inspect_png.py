import struct

with open(r"D:\slax\boot\grub\bootlogo.png", "rb") as f:
    data = f.read()

print("File size:", len(data))
# Check chunks
pos = 8
while pos < len(data):
    length, chunk_type = struct.unpack(">I4s", data[pos:pos+8])
    pos += 8
    print(f"Chunk: {chunk_type.decode('ascii', errors='replace')}, Length: {length}")
    pos += length + 4 # skip data + CRC
    if chunk_type == b"IEND":
        break
