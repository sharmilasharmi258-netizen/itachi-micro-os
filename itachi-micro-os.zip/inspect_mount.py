with open(r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\initrd_unpack\lib_livekitlib", "r", encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "mount_device" in line or "mount_bundle" in line or "fstab" in line:
        print(f"Line {i+1}: {line.strip()}")
