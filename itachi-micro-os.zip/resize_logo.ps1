Add-Type -AssemblyName System.Drawing
$srcPath = "C:\Users\sharm\Downloads\micro os\assets\logo.png"
$dstPath = "C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\ready\bootlogo.png"

$srcImg = [System.Drawing.Image]::FromFile($srcPath)
$targetWidth = 160
$targetHeight = 240

$bmp = New-Object System.Drawing.Bitmap($targetWidth, $targetHeight)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$g.Clear([System.Drawing.Color]::Black)

$g.DrawImage($srcImg, 0, 0, $targetWidth, $targetHeight)
$g.Dispose()
$srcImg.Dispose()

$bmp.Save($dstPath, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

Write-Host "Resized logo successfully to 160x240 at $dstPath"
