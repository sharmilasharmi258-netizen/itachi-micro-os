# Micro-OS Architecture Specification
**Course:** Operating Systems | Continuous Assessment 6 (15 Marks)
**Project Title:** Itachi Micro-OS: Educational Systems Construction in Rust

---

## 1. System Architecture Overview

The Micro-OS is engineered according to a layered, modular operating-system architecture where low-level hardware abstractions feed into kernel execution mechanisms, which in turn support CPU scheduling, concurrency, memory allocation, and user-space transitions.

```mermaid
flowchart TD
    subgraph HW ["Layer 0: Hardware / Emulation Layer"]
        CPU["x86_64 CPU / Registers"]
        TimerHW["Programmable Interval Timer (PIT / APIC)"]
        RAM["Physical Memory / RAM"]
        ConsoleHW["VGA / Serial UART"]
    end

    subgraph Entry ["Layer 1 & 2: Boot & Diagnostics"]
        Boot["Kernel Boot Entry (boot_sequence)"]
        Diagnostics["Kernel Logger & Diagnostics (klog)"]
        ConsoleDriver["Console & Terminal Driver (ANSI / VGA)"]
    end

    subgraph Memory ["Layer 8: Memory Subsystem"]
        Bump["Bump Allocator (Contiguous Heap)"]
        Frame["Frame Allocator (4KB Page Bitmap)"]
    end

    subgraph Sync ["Layer 7: Concurrency & Synchronization"]
        Spin["Spinlock<T> (Atomic Test-and-Set)"]
        Guard["RAII SpinlockGuard<T>"]
    end

    subgraph TaskSubsys ["Layers 3-6: CPU Task Scheduling"]
        TCB["Task Control Blocks (TCB / Context / Metrics)"]
        ReadyQ["Ready Queue (FIFO / Priority)"]
        Timer["Timer Subsystem (SystemTimer / IRQ0)"]
        Scheduler["Round Robin / Priority Scheduler"]
    end

    subgraph SysInterface ["Layer 9 & 10: Interface & Integrated Demo"]
        Syscall["Syscall Dispatcher (User -> Kernel)"]
        IntegratedDemo["Integrated Execution Orchestrator"]
    end

    CPU --> Boot
    TimerHW --> Timer
    RAM --> Frame
    ConsoleHW --> ConsoleDriver

    Boot --> Diagnostics
    Diagnostics --> ConsoleDriver

    Boot --> Bump
    Bump --> Frame

    Boot --> Spin
    Spin --> Guard

    Timer --> Scheduler
    TCB --> ReadyQ
    ReadyQ --> Scheduler
    Scheduler --> CPU

    Scheduler --> Syscall
    Syscall --> IntegratedDemo
```

---

## 2. Kernel Execution Flow (Layer 10 Lifecycle)

```mermaid
sequenceDiagram
    autonumber
    actor Bootloader
    participant Kernel as Kernel Entry (Layer 1)
    participant Console as Diagnostics (Layer 2)
    participant Mem as Allocator (Layer 8)
    participant Sync as Spinlock (Layer 7)
    participant Sched as Scheduler (Layers 3-5)
    participant Timer as System Timer (Layer 6)

    Bootloader->>Kernel: Transfer Execution (x86_64)
    Kernel->>Console: print_startup_banner() (Itachi Motif)
    Kernel->>Console: init_logger(Trace, "scheduler_trace.log")
    Kernel->>Mem: BumpAllocator::new() & FrameAllocator::new()
    Mem-->>Kernel: Memory Heap & Physical Frames Active
    Kernel->>Sync: run_synchronization_demonstration()
    Sync-->>Kernel: Verified Race-Free Atomic Mutual Exclusion
    Kernel->>Sched: Initialize ReadyQueue & Tasks (PID-1 to PID-4)
    loop Every Clock Tick
        Timer->>Sched: tick(current_tick)
        alt Quantum Expired
            Sched->>Sched: Context Switch (Save TCB, Load Next TCB)
        else Task Finished
            Sched->>Sched: Mark TERMINATED, Calculate Turnaround & Wait Time
        end
    end
    Sched->>Console: Print Performance Summary & Export CSV Trace
```

---

## 3. Subsystem Breakdown

### Layer 1 & 2: Boot & Structured Diagnostics
- **Boot Entry:** Verifies target architecture (`x86_64`), initializes system descriptors, and renders the high-visibility Itachi Akatsuki console banner.
- **Diagnostics Logger:** Provides microsecond timestamping, structured tags (`[BOOT]`, `[SCHED]`, `[MEM]`, `[SYNC]`, `[TASK]`, `[SYS]`), and dual emission to stdout and persistent log files.

### Layers 3, 4, 5 & 6: Task Management, Ready Queue, Scheduler & Timer
- **Task Control Block (`Task`):** Encapsulates unique `TaskId`, simulated CPU registers (`TaskContext`), dynamic execution state (`Ready`, `Running`, `Blocked`, `Terminated`), priority, and performance accounting fields.
- **Ready Queue (`ReadyQueue`):** Doubly-linked / circular queue implementing deterministic FIFO insertion and retrieval, with support for priority selection and aging.
- **Scheduler (`Scheduler`):** Implements time-sliced Round Robin preemption (Layer 5) and dynamic Priority Scheduling with Aging (Specialization Track A).
- **Timer (`SystemTimer`):** Drives periodic hardware clock ticks (100 Hz), tracking uptime and firing scheduler preemption checks.

### Layer 7: Concurrency & Synchronization
- **Spinlock (`Spinlock<T>`):** Employs atomic `compare_exchange_weak` with `Acquire`/`Release` memory ordering semantics. Provides safe RAII locking via `SpinlockGuard<T>`, guaranteeing zero data races without external OS kernel dependencies.

### Layer 8: Memory Subsystem
- **Bump Allocator:** Provides $O(1)$ linear contiguous heap allocations with pointer alignment.
- **Page Frame Allocator:** Manages a compact 64-bit word bitmap representing physical 4KB memory frames, supporting frame allocation and double-free validation.

### Layer 9: System Interface & Syscalls
- Dispatches user requests across the protection boundary (`Yield`, `Spawn`, `Exit`, `Print`, `AllocFrame`).
