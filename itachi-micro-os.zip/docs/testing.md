# Micro-OS Systematic Testing & Validation Plan
**Course:** Operating Systems | CA-6 Engineering Project
**Subject:** Test Specifications TC1 through TC6 (Section 16 Rubric)

---

## 1. Test Strategy & Levels

Testing is conducted across three levels in accordance with CA-6 Section 15:
1. **Level 1 (Unit Testing):** Allocator bounds, Ready Queue FIFO semantics, Spinlock lock/unlock.
2. **Level 2 (Mechanism Testing):** Timer quantum preemption, priority aging, memory double-free rejection.
3. **Level 3 (Integration Testing):** Full lifecycle boot-to-termination execution with concurrent tasks.

---

## 2. Test Case Specifications & Empirical Results

| Test Case | Objective | Input Configuration | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|
| **TC1** | Minimum Configuration | 2 Tasks, Burst = 4, Quantum = 2 | Interleaved execution (T1 -> T2 -> T1 -> T2) | Interleaved execution verified; exactly 4 switches | **PASS** |
| **TC2** | Multiple Tasks | 5 Tasks, Bursts = [5, 3, 7, 2, 4], Quantum = 2 | All 5 tasks reach TERMINATED state without deadlock | 5/5 tasks completed; 12 context switches logged | **PASS** |
| **TC3** | Boundary Case | 2 Tasks, Quantum = 1 tick | Maximum context switching frequency | 5 switches logged; 1-tick preemption verified | **PASS** |
| **TC4** | Stress Case | 20 Concurrent Tasks, Burst = 3 each | High queue density handled without stack overflow | All 20 tasks completed in 61 ticks | **PASS** |
| **TC5** | Failure Case | Allocate 2048B on 1024B heap; Double-free frame #0 | Safe error handling: `OUT_OF_MEMORY` & `DOUBLE_FREE` | Errors caught cleanly without kernel panic | **PASS** |
| **TC6** | Repeatability | Repeated execution of identical 2-task workload | Deterministic, bit-identical context switch counts | Run 1: 4 switches, Run 2: 4 switches (100% Match) | **PASS** |

---

## 3. How to Run the Test Suite

Run individual test cases:
```bash
# Run Test Case 1 (Minimum Configuration)
cargo run --release -- --tc 1

# Run Test Case 5 (Failure & Boundary Handling)
cargo run --release -- --tc 5

# Run the entire systematic suite (TC1 - TC6)
cargo run --release -- --all-tests
```

Run Rust standard unit and integration tests:
```bash
cargo test
```
