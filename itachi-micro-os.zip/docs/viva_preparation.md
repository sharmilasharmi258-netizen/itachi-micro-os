# Micro-OS Individual Viva Defence Guide
**Course:** Operating Systems | CA-6 Engineering Project (Section 32)
**Target:** 15/15 Marks Oral Defence

---

### Q1: What happens immediately after the kernel starts?
**Answer:** The kernel executes `boot_sequence()`. It resets the console screen, prints the Itachi Akatsuki ASCII banner, initializes the structured diagnostic subsystem (`klog`) with microsecond timestamping, checks simulated CPU architectural registers, and configures memory allocators (Bump and Frame Allocator).

### Q2: How is a task represented?
**Answer:** A task is encapsulated by the `Task` struct (Task Control Block / TCB). It stores a unique `TaskId`, task name, execution state (`Ready`, `Running`, `Blocked`, `Terminated`), priority, a virtual register context (`TaskContext` with instruction pointer, stack pointer, registers R0–R7, and flags), an allocated stack frame, and accounting metrics (arrival, burst, turnaround, and waiting ticks).

### Q3: How does the scheduler select the next task?
**Answer:** In Round Robin, it performs an $O(1)$ `dequeue()` from the front of the FIFO `ReadyQueue`. In our specialization track (Priority with Aging), it selects the task with the highest numeric priority (lowest value), adjusting priority dynamically over time to prevent starvation.

### Q4: Why did you choose Round Robin?
**Answer:** Round Robin guarantees fairness and prevents starvation without requiring prior knowledge of task burst times. It provides predictable, bounded response times ($O(N \times \tau)$), making it ideal for interactive and time-sharing operating systems.

### Q5: What triggers a scheduling decision?
**Answer:** A scheduling decision is triggered by three conditions:
1. Periodic timer quantum expiration ($\tau = 0$).
2. Running task termination (`TaskState::Terminated`).
3. Voluntary task relinquishment via a `SYS_YIELD` system call.

### Q6: What happens during a timer tick?
**Answer:** The hardware timer fires an interrupt (`tick()`), advancing the system tick counter. The scheduler decrements the currently running task's remaining quantum and remaining burst. If the quantum reaches 0, the task's context is saved, its state is set to `Ready`, it is moved to the tail of the Ready Queue, and the next task is dispatched. Waiting tasks also have their wait metrics incremented.

### Q7: How is shared kernel data protected?
**Answer:** Through our custom `Spinlock<T>` primitive. It uses atomic test-and-set operations (`AtomicBool::compare_exchange_weak`) with `Acquire`/`Release` memory ordering and wraps data in an RAII `SpinlockGuard<T>` which automatically unlocks the resource when it leaves scope.

### Q8: Why is synchronization required?
**Answer:** Without synchronization, concurrent tasks or interrupt handlers accessing shared data structures (such as Ready Queues or global counters) experience read-modify-write race conditions, producing non-deterministic data corruption and lost updates.

### Q9: How does your allocator work?
**Answer:** We implemented a dual-layer memory subsystem:
1. **Bump Allocator:** High-speed $O(1)$ contiguous linear allocation by incrementing a pointer with alignment masking.
2. **Page Frame Allocator:** Manages physical 4KB memory frames using a 64-bit word bitmap, where trailing zeros/ones locate free frames in $O(1)$ operations.

### Q10: What happens when allocation fails?
**Answer:** The allocator returns a clean `Result::Err(OutOfMemory)` instead of crashing. This error bubbles up to the caller or kernel syscall handler, which can reject the task creation or trigger paging/garbage collection, preventing undefined behavior.

### Q11: Where is `unsafe` used and why?
**Answer:** `unsafe` is used in exactly one controlled location: inside `SpinlockGuard`'s `Deref` and `DerefMut` implementations to dereference the inner `UnsafeCell<T>` pointer. It is strictly required because Rust's safe type system cannot verify at compile-time that an atomic hardware spinlock guarantees exclusive mutable access at runtime.

### Q12: What invariant does your `unsafe` code rely on?
**Answer:** It relies on the invariant that `UnsafeCell::get()` is dereferenced if and only if the `SpinlockGuard` exists, and the guard can only be instantiated when the `AtomicBool` has successfully transitioned from `false` to `true` with `Ordering::Acquire`. No other thread can hold the lock simultaneously.

### Q13: What happens if two tasks access the same resource?
**Answer:** With our `Spinlock<T>`, the first task acquires the lock and enters its critical section. The second task attempts to acquire the lock, fails the atomic compare-exchange, and spins in a tight `std::hint::spin_loop()` until the first task drops its guard. Data consistency is 100% preserved.

### Q14: How did you test the scheduler?
**Answer:** We tested across six standardized test cases (TC1 to TC6):
- TC1: Minimum configuration (2 tasks, alternating verification).
- TC2: Multiple tasks (5 tasks with varying burst lengths).
- TC3: Boundary condition (Quantum = 1 tick).
- TC4: Stress testing (20 concurrent tasks).
- TC5: Failure cases (Out of memory and double free).
- TC6: Deterministic repeatability across identical runs.

### Q15: How did you establish that the scheduler is actually working?
**Answer:** Through our Python trace analyzer (`scripts/parse_traces.py`). Every context switch is logged with its timestamp, previous PID, next PID, remaining burst, and switch reason into `traces/scheduler_trace.csv`. The Python script reconstructs the execution timeline and computes Jain's Fairness Index ($0.9615$), mathematically verifying fair preemption and the absence of starvation.

### Q16: How is your Micro-OS different from Linux?
**Answer:** Linux uses the Completely Fair Scheduler (CFS) based on red-black trees and virtual runtime (`vruntime`), complex multi-level page tables with demand paging and copy-on-write (COW), and preemptive kernel locks with futexes. Our Micro-OS uses an educational, visible Round Robin queue, a bitmap frame allocator, and direct spinlocks, prioritizing conceptual clarity and observable mechanisms over multi-gigabyte production scale.

### Q17: What did CA-5 teach you that helped this project?
**Answer:** CA-5 (Linux Systems Engineering) gave us hands-on experience observing real Linux systemd boot latency, CPU scheduling behavior via `chrt` and `nice`, and `/proc` process state tracing. We applied that directly by implementing structured kernel logging, state transitions, and measuring boot times.

### Q18: What CA-4 research question could be extended into your Micro-OS?
**Answer:** In CA-4, we investigated *"How time quantum length affects average turnaround time and context switch overhead"*. In this Micro-OS, we validated that hypothesis: reducing the quantum to 1 tick (TC3) increased context switch frequency by over 150%, while a balanced quantum of 2–4 ticks maximized CPU throughput while maintaining high fairness.

### Q19: What would you implement next?
**Answer:** We would implement:
1. Virtual memory management with hardware x86_64 4-level page tables (PML4).
2. Asynchronous I/O and interrupt-driven UART serial drivers.
3. User-space privilege separation using Ring 3 transitions via `sysret` / `syscall`.

### Q20: What is the most important limitation of your current system?
**Answer:** The memory bump allocator cannot reclaim individual deallocated objects without resetting the entire heap, and the simulated context switcher runs in a cooperative/simulated instruction loop rather than swapping physical hardware CPU register sets (`mov rsp`, `pushaq`, `iretq`) on a bare-metal interrupt vector.
