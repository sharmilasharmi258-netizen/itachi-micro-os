# Micro-OS Detailed Design Document
**Course:** Operating Systems | CA-6 Engineering Project
**Subject:** Systems Design, Rust Abstractions & Invariants

---

## 1. Design Principles & Goals

1. **Deterministic Execution:** The kernel is designed so that given an identical task arrival sequence and time quantum, scheduler state transitions and context switches are 100% reproducible.
2. **Explicit Mechanism Visibility:** Operating system abstractions (TCBs, Ready Queues, Allocator Bitmaps, Spinlocks) are exposed directly to logging and trace analyzers rather than hidden inside opaque black boxes.
3. **Safety & Controlled Unsafe Rust:** Zero unexplained `unsafe` blocks. Low-level interior mutability and raw pointers are isolated strictly behind safe Rust RAII abstractions.

---

## 2. Low-Level Subsystem Design

### 2.1 Concurrency & Spinlock Invariants (`src/sync/mod.rs`)

The `Spinlock<T>` relies on `std::sync::atomic::AtomicBool` and `std::cell::UnsafeCell<T>`.

#### Memory Ordering Strategy:
- **Lock Acquisition:** `compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed)`
  - *Rationale:* `Ordering::Acquire` ensures that all subsequent memory reads and writes to the protected resource cannot be reordered before the lock is successfully acquired.
- **Lock Release:** `store(false, Ordering::Release)`
  - *Rationale:* `Ordering::Release` ensures that all memory modifications performed inside the critical section become visible to other CPU cores before the lock flag is reset to false.

#### Justification for `unsafe` Usage:
```rust
// Deref implementation
unsafe { &*self.lock.data.get() }
```
- **Invariant:** The pointer returned by `data.get()` is dereferenced if and only if the `SpinlockGuard` exists.
- **Precondition:** The guard can only be instantiated after `AtomicBool` has successfully transitioned from `false` to `true`.
- **Postcondition:** The lock cannot be acquired by any other thread/task until the guard goes out of scope and calls `drop()`.

---

### 2.2 Memory Management Design (`src/memory/mod.rs`)

#### Bump Allocator:
- **Algorithm:** Linear offset advancement:
  $$\text{aligned\_start} = (\text{next} + \text{align} - 1) \ \& \ !(\text{align} - 1)$$
- **Complexity:** $O(1)$ allocation time, zero metadata overhead per allocation.
- **Limitation:** Individual allocations cannot be reclaimed until a complete arena reset occurs.

#### Frame Allocator (Bitmap):
- **Algorithm:** Scans a vector of `u64` words. Trailing ones count (`trailing_ones()`) rapidly identifies the first unset (free) frame in $O(1)$ CPU operations.
- **Safety Invariant:** `deallocate_frame()` performs bitmask verification:
  $$\text{if } (\text{bitmap}[\text{word}] \ \& \ \text{mask}) == 0 \implies \text{Double-Free Error}$$
  This prevents memory corruption and accidental duplicate allocations.

---

### 2.3 Task Representation & Context Switching (`src/task/mod.rs` & `src/scheduler/mod.rs`)

#### Task State Machine:
```text
  [NEW] ---> READY <===================> RUNNING ---> TERMINATED
               ^                            |
               |                            |
               +---------- BLOCKED <--------+
```

- **READY:** Resides in the `ReadyQueue` awaiting CPU dispatch.
- **RUNNING:** Active task currently executing on the simulated CPU core.
- **TERMINATED:** Task burst completed; exit code and metrics frozen.

#### Round Robin Scheduler Engine:
- **Quantum:** Configured to $\tau = 2$ ticks by default.
- **Preemption Rule:**
  $$\text{If } \tau_{\text{remaining}} == 0 \text{ and } T_{\text{burst\_remaining}} > 0 \implies \text{Enqueue to Tail of Ready Queue}$$
- **Starvation Freedom:** Guaranteed by cyclic FIFO ordering. Every runnable task is guaranteed to receive CPU time within at most $N \times \tau$ ticks.

---

### 2.4 Specialization Track A: Priority Scheduling with Aging

To prevent indefinite postponement (starvation) of low-priority tasks:
- **Aging Rule:** Every $K = 4$ clock ticks spent waiting in the Ready Queue, a task's priority numeric value is decremented (higher priority):
  $$P_{\text{effective}} = \max(0, P_{\text{base}} - \lfloor \Delta t_{\text{wait}} / K \rfloor)$$
- This ensures that long-waiting background tasks dynamically ascend to the head of the queue.
