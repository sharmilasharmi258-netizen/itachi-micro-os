import json

with open(r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\.system_generated\logs\transcript.jsonl", "r", encoding="utf-8") as f:
    for line in f:
        if "itachi_bootlogo.png" in line and "Add-Type -AssemblyName System.Drawing" in line:
            obj = json.loads(line)
            calls = obj.get("tool_calls", [])
            for c in calls:
                args = c.get("args", {})
                cmd = args.get("CommandLine", "")
                if "itachi_bootlogo.png" in cmd:
                    print(cmd)
