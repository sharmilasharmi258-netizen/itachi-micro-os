import struct, zlib

with open(r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\itachi_welcome_bootlogo.png", "rb") as f:
    data = f.read()

pos = 8
idat = []
while pos < len(data):
    length, t = struct.unpack(">I4s", data[pos:pos+8])
    pos += 8
    d = data[pos:pos+length]
    pos += length + 4
    if t == b"IDAT": idat.append(d)
    elif t == b"IEND": break

raw = zlib.decompress(b"".join(idat))
w, h = 640, 480
row_sz = 1 + w * 3

for band in range(0, 480, 40):
    cnt = 0
    for y in range(band, min(band+40, 480)):
        row = raw[y*row_sz+1 : (y+1)*row_sz]
        for x in range(w):
            if sum(row[x*3 : x*3+3]) > 30:
                cnt += 1
    print(f"Y [{band:3d} - {band+40:3d}]: {cnt} non-black pixels")
