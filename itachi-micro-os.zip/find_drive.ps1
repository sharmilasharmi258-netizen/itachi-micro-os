$letters = 68..90 | ForEach-Object { [char]$_ + ':\' }
foreach ($l in $letters) {
    if (Test-Path "$l\slax") {
        Write-Output "FOUND_SLAX: $l"
    } elseif (Test-Path $l) {
        Write-Output "ACCESSIBLE_DRIVE: $l"
    }
}
