use micro_os::memory::{BumpAllocator, FrameAllocator};
use micro_os::scheduler::{Scheduler, SchedulingPolicy};
use micro_os::sync::Spinlock;
use micro_os::task::Task;
use micro_os::timer::SystemTimer;

#[test]
fn test_round_robin_scheduling() {
    let mut sched = Scheduler::new(SchedulingPolicy::RoundRobin, 2);
    let mut timer = SystemTimer::new(100);

    sched.add_task(Task::new(1, "Test_A", 1, 4, 0));
    sched.add_task(Task::new(2, "Test_B", 1, 4, 0));

    while !sched.is_all_completed() {
        let t = timer.tick();
        sched.tick(t);
    }

    assert_eq!(sched.completed_tasks.len(), 2);
    let summary = sched.compute_summary(timer.current_ticks());
    assert_eq!(summary.completed_tasks, 2);
    assert!(summary.total_context_switches >= 3);
}

#[test]
fn test_priority_scheduling_with_aging() {
    let mut sched = Scheduler::new(SchedulingPolicy::PriorityWithAging, 2);
    let mut timer = SystemTimer::new(100);

    // High priority (0) and lower priority (5)
    sched.add_task(Task::new(1, "Low_Prio_Task", 5, 4, 0));
    sched.add_task(Task::new(2, "High_Prio_Task", 0, 4, 0));

    while !sched.is_all_completed() {
        let t = timer.tick();
        sched.tick(t);
    }

    assert_eq!(sched.completed_tasks.len(), 2);
}

#[test]
fn test_spinlock_synchronization() {
    let lock = Spinlock::new(42);
    {
        let mut guard = lock.lock();
        assert_eq!(*guard, 42);
        *guard = 100;
    }
    assert_eq!(*lock.lock(), 100);
}

#[test]
fn test_bump_allocator() {
    let mut alloc = BumpAllocator::new(0x1000, 1024);
    let a1 = alloc.allocate(64, 8).unwrap();
    let a2 = alloc.allocate(128, 8).unwrap();
    assert_eq!(a1, 0x1000);
    assert!(a2 >= 0x1040);
    assert!(alloc.allocate(2048, 8).is_err()); // OOM test
}

#[test]
fn test_page_frame_allocator() {
    let mut alloc = FrameAllocator::new(64);
    let f1 = alloc.allocate_frame().unwrap();
    let f2 = alloc.allocate_frame().unwrap();
    assert_ne!(f1, f2);
    assert_eq!(alloc.allocated_count(), 2);

    alloc.deallocate_frame(f1).unwrap();
    assert_eq!(alloc.allocated_count(), 1);
    assert!(alloc.deallocate_frame(f1).is_err()); // Double free error test
}
