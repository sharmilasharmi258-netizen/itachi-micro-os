import os

ps_script = '''
Add-Type -AssemblyName System.Drawing

$srcPath = "c:\\Users\\sharm\\Downloads\\micro os\\assets\\logo.png"
$dstPath = "C:\\Users\\sharm\\.gemini\\antigravity\\brain\\18b1549f-f6bd-4253-acd7-77b4b9e97d29\\scratch\\itachi_perfect_bootlogo.png"

$src = [System.Drawing.Image]::FromFile($srcPath)
$canvas = New-Object System.Drawing.Bitmap(640, 480, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
$g = [System.Drawing.Graphics]::FromImage($canvas)
$g.Clear([System.Drawing.Color]::Black)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

# 1. Centered Itachi Art: Height = 300, Width = 200
$artH = 300
$artW = [int]($artH * ($src.Width / $src.Height))
$artX = [int]((640 - $artW) / 2)
$artY = 15

$g.DrawImage($src, $artX, $artY, $artW, $artH)

# 2. Prominent Message UNDER the logo: "WELCOME TO ITACHI OS"
$titleFont = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
$titleBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 45, 45)) # Crimson Red
$shadowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(60, 0, 0)) # Deep Dark Red Shadow

$sf = New-Object System.Drawing.StringFormat
$sf.Alignment = [System.Drawing.StringAlignment]::Center
$sf.LineAlignment = [System.Drawing.StringAlignment]::Center

$titleText = "WELCOME TO ITACHI OS"
# Draw drop shadow then crimson text
$g.DrawString($titleText, $titleFont, $shadowBrush, [System.Drawing.RectangleF]::new(2, 322, 640, 32), $sf)
$g.DrawString($titleText, $titleFont, $titleBrush, [System.Drawing.RectangleF]::new(0, 320, 640, 32), $sf)

# 3. Subtitle under welcome text: "CONTINUOUS ASSESSMENT 6 • LIVE KERNEL"
$subFont = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$subBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(170, 170, 170))
$subText = "CONTINUOUS ASSESSMENT 6 • OPERATING SYSTEMS PROJECT"
$g.DrawString($subText, $subFont, $subBrush, [System.Drawing.RectangleF]::new(0, 352, 640, 18), $sf)

$canvas.Save($dstPath, [System.Drawing.Imaging.ImageFormat]::Png)

$g.Dispose()
$canvas.Dispose()
$src.Dispose()

Write-Host "Created perfect Itachi boot logo with welcome message at $dstPath"
'''

with open("generate_perfect_logo.ps1", "w", encoding="utf-8") as f:
    f.write(ps_script)

print("Saved generate_perfect_logo.ps1")
