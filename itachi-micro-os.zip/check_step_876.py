import json

with open(r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\.system_generated\logs\transcript.jsonl", "r", encoding="utf-8") as f:
    for line in f:
        obj = json.loads(line)
        idx = obj.get("step_index", 0)
        if 870 <= idx <= 885:
            calls = obj.get("tool_calls", [])
            for c in calls:
                args = c.get("args", {})
                cmd = args.get("CommandLine", "")
                if "theme.txt" in cmd or "bootlogo" in cmd:
                    print(f"Step {idx}: {cmd[:500]}")
                    print("---")
