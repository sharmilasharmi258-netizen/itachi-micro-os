import lzma
import os

initrd_path = r"D:\slax\boot\initrfs.img"
out_dir = r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\initrd_unpack"

with lzma.open(initrd_path, "rb") as f_in:
    data = f_in.read()

pos = 0
while pos < len(data):
    if pos + 110 > len(data):
        break
    magic = data[pos:pos+6]
    if magic != b"070701" and magic != b"070702":
        break
    
    filesize = int(data[pos+54:pos+62], 16)
    namesize = int(data[pos+94:pos+102], 16)
    
    name_pos = pos + 110
    filename = data[name_pos:name_pos+namesize-1].decode("utf-8", errors="replace")
    
    file_pos = (name_pos + namesize + 3) & ~3
    file_data = data[file_pos:file_pos+filesize]
    
    if filename == "TRAILER!!!":
        break
        
    pos = (file_pos + filesize + 3) & ~3
    
    if "livekit" in filename or "config" in filename or "splash" in filename:
        clean_name = filename.replace("/", "_")
        out_path = os.path.join(out_dir, clean_name)
        with open(out_path, "wb") as out_f:
            out_f.write(file_data)
        print("Extracted:", filename)
