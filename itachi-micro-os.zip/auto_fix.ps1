$logFile = "C:\Users\sharm\Downloads\micro os\repair_log.txt"
"=== Starting Auto-Deploy at $(Get-Date) ===" | Out-File $logFile

# 1. Detect target USB drive letter
$targetDrive = $null
foreach ($letter in @("D:", "E:", "F:", "G:")) {
    if (Test-Path "$letter\slax") {
        $targetDrive = $letter
        break
    }
}

if (-not $targetDrive) {
    "ERROR: Could not locate pendrive with \slax directory." | Out-File $logFile -Append
    Write-Error "Could not find USB drive with \slax folder. Drives checked: D:, E:, F:, G:"
    exit 1
}

"Target drive identified as $targetDrive" | Out-File $logFile -Append
Write-Host "Target drive identified as $targetDrive"

# 2. Set volume label cleanly
try {
    $driveInfo = [System.IO.DriveInfo]::new($targetDrive)
    $driveInfo.VolumeLabel = "ITACHI-OS"
    "Volume label set to ITACHI-OS" | Out-File $logFile -Append
    Write-Host "Volume label set to ITACHI-OS"
} catch {
    "Note: Volume label update skipped ($($_.Exception.Message))" | Out-File $logFile -Append
}

# 3. Clean any stale session
if (Test-Path "$targetDrive\slax\changes\last_session.txt") {
    Remove-Item "$targetDrive\slax\changes\last_session.txt" -Force -ErrorAction SilentlyContinue
}
if (Test-Path "$targetDrive\slax\changes\1") {
    Remove-Item "$targetDrive\slax\changes\1" -Recurse -Force -ErrorAction SilentlyContinue
}
"Stale session files cleaned" | Out-File $logFile -Append
Write-Host "Stale session files cleaned"

# 4. Deploy Bootloader configuration & theme
$readyDir = "C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\ready"
$slx = "C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\universal_slax_grub.cfg"

New-Item -ItemType Directory -Path "$targetDrive\slax\boot" -Force -ErrorAction SilentlyContinue | Out-Null
New-Item -ItemType Directory -Path "$targetDrive\slax\boot\grub" -Force -ErrorAction SilentlyContinue | Out-Null
New-Item -ItemType Directory -Path "$targetDrive\boot\grub" -Force -ErrorAction SilentlyContinue | Out-Null

Copy-Item $slx "$targetDrive\slax\boot\grub.cfg" -Force
Copy-Item $slx "$targetDrive\boot\grub\grub.cfg" -Force

Copy-Item "$readyDir\entries.cfg" "$targetDrive\slax\boot\grub\entries.cfg" -Force
Copy-Item "$readyDir\entries.cfg" "$targetDrive\slax\boot\grub\autoboot.cfg" -Force
Copy-Item "$readyDir\entries.cfg" "$targetDrive\slax\boot\grub\itachi_entries.cfg" -Force

Copy-Item "$readyDir\bootlogo.png" "$targetDrive\slax\boot\grub\bootlogo.png" -Force
Copy-Item "$readyDir\bootlogo.png" "$targetDrive\boot\grub\bootlogo.png" -Force
if (Test-Path "$targetDrive\EFI\BOOT") {
    Copy-Item "$readyDir\bootlogo.png" "$targetDrive\EFI\BOOT\itachi_logo.png" -Force
}
"Bootloader and Itachi Boot Logo deployed" | Out-File $logFile -Append
Write-Host "Bootloader and Itachi Boot Logo deployed"

# 5. Rootcopy deployment: Terminal, Snap Store, Reboot to Windows
New-Item -ItemType Directory -Path "$targetDrive\slax\rootcopy\usr\local\bin" -Force | Out-Null
New-Item -ItemType Directory -Path "$targetDrive\slax\rootcopy\root\Desktop" -Force | Out-Null
New-Item -ItemType Directory -Path "$targetDrive\slax\rootcopy\usr\share\applications" -Force | Out-Null
New-Item -ItemType Directory -Path "$targetDrive\slax\rootcopy\run" -Force | Out-Null

# Terminal
Copy-Item "$readyDir\x-terminal-emulator" "$targetDrive\slax\rootcopy\usr\local\bin\x-terminal-emulator" -Force
Copy-Item "$readyDir\x-terminal-emulator" "$targetDrive\slax\rootcopy\usr\local\bin\terminal" -Force
Copy-Item "$readyDir\terminal.desktop" "$targetDrive\slax\rootcopy\root\Desktop\terminal.desktop" -Force
Copy-Item "$readyDir\terminal.desktop" "$targetDrive\slax\rootcopy\usr\share\applications\terminal.desktop" -Force

# Snap Store & App Installer
Copy-Item "$readyDir\snap-store" "$targetDrive\slax\rootcopy\usr\local\bin\snap-store" -Force
Copy-Item "$readyDir\snap-installer" "$targetDrive\slax\rootcopy\usr\local\bin\snap-installer" -Force
Copy-Item "$readyDir\snap-store.desktop" "$targetDrive\slax\rootcopy\root\Desktop\snap-store.desktop" -Force
Copy-Item "$readyDir\snap-store.desktop" "$targetDrive\slax\rootcopy\usr\share\applications\snap-store.desktop" -Force
Copy-Item "$readyDir\snap-installer.desktop" "$targetDrive\slax\rootcopy\root\Desktop\snap-installer.desktop" -Force
Copy-Item "$readyDir\snap-installer.desktop" "$targetDrive\slax\rootcopy\usr\share\applications\snap-installer.desktop" -Force

# Reboot to Windows & Power Off Shortcuts
Copy-Item "$readyDir\reboot-to-windows.desktop" "$targetDrive\slax\rootcopy\root\Desktop\reboot-to-windows.desktop" -Force
Copy-Item "$readyDir\reboot-to-windows.desktop" "$targetDrive\slax\rootcopy\usr\share\applications\reboot-to-windows.desktop" -Force
Copy-Item "$readyDir\poweroff.desktop" "$targetDrive\slax\rootcopy\root\Desktop\poweroff.desktop" -Force
Copy-Item "$readyDir\poweroff.desktop" "$targetDrive\slax\rootcopy\usr\share\applications\poweroff.desktop" -Force

# Preinit script
Copy-Item "$readyDir\preinit.sh" "$targetDrive\slax\rootcopy\run\preinit.sh" -Force

"Desktop shortcuts and preinit hooks deployed" | Out-File $logFile -Append
Write-Host "Desktop shortcuts and preinit hooks deployed"

# 6. Verification
$desktopFiles = Get-ChildItem "$targetDrive\slax\rootcopy\root\Desktop"
"Files on Desktop:" | Out-File $logFile -Append
$desktopFiles | ForEach-Object { $_.Name } | Out-File $logFile -Append

Write-Host "SUCCESS: Deployment completed successfully on $targetDrive!"
"=== Deployment Finished Successfully at $(Get-Date) ===" | Out-File $logFile -Append
