import shutil, os

src = r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\itachi_perfect_bootlogo.png"
shutil.copy2(src, r"D:\slax\boot\grub\bootlogo.png")
shutil.copy2(src, r"D:\boot\grub\bootlogo.png")
if os.path.exists(r"D:\EFI\BOOT"):
    shutil.copy2(src, r"D:\EFI\BOOT\itachi_logo.png")

theme = """# Itachi OS - GRUB Theme Layout
title-text: ""
desktop-image: "black.png"

+ image {
   left = "50%-320"
   top = "50%-230"
   width = 640
   height = 480
   file = "/slax/boot/grub/bootlogo.png"
}

+ boot_menu {
   left = "50%-340"
   top = "50%+150"
   width = 680
   height = 95
   item_font = "Unifont Regular 16"
   item_color = "#AAAAAA"
   selected_item_color = "#FFFFFF"
   selected_item_pixmap_style = "selected_*.png"
   item_height = 18
   item_spacing = 2
   item_padding = 1
   icon_width = 0
   icon_height = 0
   item_icon_space = 0
   scrollbar = false
}

+ label {
   left = "50%-340"
   top = "100%-35"
   width = 680
   height = 20
   text = "[Enter] Boot Selected OS"
   font = "Unifont Regular 16"
   color = "#FF3333"
   align = "center"
}
"""

with open(r"D:\slax\boot\grub\theme.txt", "wb") as f:
    f.write(theme.replace("\r\n", "\n").encode("utf-8"))

autoboot = """# Itachi OS - Countdown Layout
title-text: ""
desktop-image: "black.png"

+ image {
   left = "50%-320"
   top = "50%-230"
   width = 640
   height = 480
   file = "/slax/boot/grub/bootlogo.png"
}

+ label {
   id = "__timeout__"
   left = "50%-340"
   top = "50%+155"
   width = 680
   height = 20
   text = "Press Esc for boot menu, automatic boot in %d s ..."
   font = "Unifont Regular 16"
   color = "#FFFFFF"
   align = "center"
}
"""

with open(r"D:\slax\boot\grub\autoboot.txt", "wb") as f:
    f.write(autoboot.replace("\r\n", "\n").encode("utf-8"))

print("PERFECT_THEME_AND_LOGO_DEPLOYED_SUCCESSFULLY")
