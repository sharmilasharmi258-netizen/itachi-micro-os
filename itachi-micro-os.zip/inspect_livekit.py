with open(r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\initrd_unpack\lib_livekitlib", "r", encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()

print(f"Total lines in livekitlib: {len(lines)}")

# Look for user_preinit, copy_rootcopy_content, change_root, splash
for i, line in enumerate(lines):
    if any(k in line for k in ["user_preinit", "copy_rootcopy_content", "change_root", "find_data", "persistent_changes"]):
        print(f"Line {i+1}: {line.strip()}")
