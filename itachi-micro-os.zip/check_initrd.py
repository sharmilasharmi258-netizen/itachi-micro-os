import os
import shutil

initrd_path = r"D:\slax\boot\initrfs.img"
out_dir = r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\initrd_unpack"
os.makedirs(out_dir, exist_ok=True)

with open(initrd_path, "rb") as f:
    header = f.read(10)
    print("Header bytes:", header.hex())

# Check magic
# gzip: 1f 8b
# xz: fd 37 7a 58 5a 00
# zstd: 28 b5 2f fd
# cpio (ASCII): 30 37 30 37 30 31 (070701)
if header[:2] == b"\x1f\x8b":
    print("Detected: GZIP")
elif header[:6] == b"\xfd7zXZ\x00":
    print("Detected: XZ")
elif header[:4] == b"\x28\xb5\x2f\xfd":
    print("Detected: ZSTD")
elif header[:6] == b"070701":
    print("Detected: uncompressed CPIO")
else:
    print("Unknown format:", header)
