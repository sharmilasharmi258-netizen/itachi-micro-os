# Step-by-Step Guide: Live Booting Micro-OS from a Pendrive
**Course:** Operating Systems | CA-6 Engineering Project
**Goal:** Prepare a bootable USB drive and live boot on your laptop in front of your professor.

---

## 1. Quick Requirements
1. **USB Flash Drive (Pendrive):** 8 GB or 16 GB minimum.
2. **Rufus or Ventoy:** Free Windows USB imaging tool ([rufus.ie](https://rufus.ie)).
3. **Debian 12 Live ISO:** Debian 12 Live with non-free firmware (e.g. `debian-live-12.x.x-amd64-standard.iso` or `debian-live-12.x.x-amd64-xfce.iso`).

---

## 2. Flashing the USB Drive on Windows (Rufus Method)

1. **Insert your USB Pendrive** into your laptop.
2. Open **Rufus**:
   - **Device:** Select your USB pendrive.
   - **Boot selection:** Select your downloaded Debian Live ISO.
   - **Partition scheme:** Choose **GPT** (for modern UEFI laptops) or **MBR** (for older BIOS laptops).
   - **Target system:** UEFI (non-CSM).
   - **File system:** Large FAT32 or NTFS.
   - **Persistent partition size:** Set to **4 GB - 8 GB** (This ensures all our changes, WiFi credentials, APT, Snap, and custom Itachi logo stay permanently saved on the pendrive across reboots!).
3. Click **START** and select **Write in ISO Image mode**. Wait 3–5 minutes until Rufus completes.

---

## 3. Applying the Custom Itachi Logo & Subsystems on the Pendrive

Once the live USB is created with persistence:
1. Boot into the live USB on your laptop.
2. Open a terminal and copy the `live_usb` folder from your repository:
   ```bash
   sudo chmod +x create_live_usb.sh
   sudo ./create_live_usb.sh
   ```
3. The script automatically:
   - Configures the custom **Itachi Uchiha Plymouth boot splash** (`assets/logo.png`).
   - Configures the **GRUB background** with the Itachi theme.
   - Installs all laptop Wi-Fi and LAN firmware (`iwlwifi`, `realtek`, `broadcom`).
   - Installs `aptitude` and configures the `alias aptitude="apt"`.
   - Enables and configures `snapd` and `snapstore`.
   - Rebuilds `initramfs` so the logo is permanently embedded into boot.

---

## 4. Live Demonstration Flow in Front of Your Professor

When demonstrating to your OS sir:

### Step 1: Power On & Boot from USB
1. Plug in your pendrive to the laptop.
2. Power on the laptop and immediately tap the **Boot Menu Key** (typically **F12** on Dell/Lenovo, **F10/Esc** on HP, **F2** on Asus/Acer).
3. Select your **USB UEFI Flash Drive** and hit **Enter**.
4. **Point to the Screen:** The GRUB bootloader appears with the **Itachi Uchiha red moon background**!
5. Select "Live Boot".
6. **Point to the Screen:** Plymouth displays the high-resolution **Itachi Uchiha boot logo** while loading kernel drivers.

---

### Step 2: Demonstrate Network Connectivity (Requirement #1)
In the terminal, run:
```bash
# Show WiFi & LAN hardware devices
ip link show

# Scan and list available Wi-Fi networks
nmcli dev wifi list

# Connect to college WiFi or phone hotspot
nmcli dev wifi connect "Your-Hotspot-Name" password "Your-Password"

# Verify live ping
ping -c 3 8.8.8.8
```
*Sir will verify that WiFi and LAN are both working on your physical laptop.*

---

### Step 3: Demonstrate Hardware Compatibility (Requirement #2)
Show that your laptop processor, display, and peripherals are recognized:
```bash
lspci -k | grep -A 3 -i "network\|vga"
uname -r
```

---

### Step 4: Demonstrate In-Built Package Manager (Requirement #3)
Show both `apt` and the required `aptitude` alias:
```bash
apt --version
aptitude --version
which aptitude
```
*Sir will see that Debian APT and aptitude alias are pre-configured.*

---

### Step 5: Demonstrate In-Built Store: Snapstore (Requirement #4)
Show that `snapd` is running and functional:
```bash
snap --version
snap list
snap find fast
```

---

### Step 6: Present Boot Time Analysis (Requirement #5)
Show the exact boot time measurement on the live machine:
```bash
systemd-analyze
systemd-analyze blame | head -n 12
systemd-analyze critical-chain
```
*Open your `live_usb/boot_analysis/boot_time_comparison.md` table and explain the exact breakdown: Base (5.27s) -> +Network (+3.07s) -> +APT (+0.60s) -> +Snapstore (+4.82s).*

---

### Step 7: Demonstrate the Rust Micro-OS Kernel (CA-6 Flagship Project)
Finally, run your Rust kernel in the terminal:
```bash
./target/release/micro_os --demo
```
*Show the Itachi ASCII console logo, Bump & Page Frame memory allocators, Spinlock race-free synchronization, and the Round-Robin CPU scheduler trace!*
