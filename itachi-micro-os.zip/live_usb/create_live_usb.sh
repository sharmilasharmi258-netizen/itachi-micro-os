#!/usr/bin/env bash
# ==============================================================================
# Micro-OS Live USB Customization & Provisioning Script
# Course: Operating Systems | Continuous Assessment 6
# Configures:
# 1. WiFi & LAN Drivers (Intel, Realtek, Broadcom)
# 2. Laptop Hardware Compatibility (non-free firmware)
# 3. APT & Aptitude package manager + alias
# 4. Snapstore & snapd service
# 5. Custom Boot Logo (Itachi Uchiha Plymouth Theme + GRUB Splash)
# ==============================================================================

set -e

if [ "$EUID" -ne 0 ]; then
  echo "[-] Please run as root (sudo ./create_live_usb.sh)"
  exit 1
fi

echo "[+] Step 1: Configuring Debian Repositories with Non-Free Firmware..."
cat <<EOF > /etc/apt/sources.list
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
EOF

apt update

echo "[+] Step 2: Installing Hardware Compatibility & Network Stack (WiFi & LAN)..."
apt install -y \
    network-manager \
    network-manager-gnome \
    wpasupplicant \
    wireless-tools \
    firmware-linux \
    firmware-linux-nonfree \
    firmware-iwlwifi \
    firmware-realtek \
    firmware-atheros \
    pciutils \
    usbutils \
    curl \
    git \
    systemd-sysv

echo "[+] Step 3: Installing and Configuring APTITUDE alias APT..."
apt install -y aptitude

# Set system-wide alias for both bash and zsh
cat <<EOF >> /etc/bash.bashrc
# Micro-OS Package Manager Alias
alias aptitude='apt'
EOF

cat <<EOF >> /etc/profile
alias aptitude='apt'
EOF

echo "[+] Step 4: Installing and Configuring Snapstore..."
apt install -y snapd apparmor
systemctl enable --now snapd.socket
systemctl enable --now snapd.service
# Optional GUI snap store
snap install snap-store || echo "[*] Snap store CLI ready. GUI available upon graphical boot."

echo "[+] Step 5: Installing Custom Boot Logo (Itachi Uchiha Plymouth Theme)..."
apt install -y plymouth plymouth-themes

THEME_DIR="/usr/share/plymouth/themes/itachi-splash"
mkdir -p "$THEME_DIR"

cp plymouth_theme/itachi-splash.plymouth "$THEME_DIR/"
cp plymouth_theme/itachi-splash.script "$THEME_DIR/"
cp plymouth_theme/itachi_logo.png "$THEME_DIR/"

# Set default plymouth theme
plymouth-set-default-theme -R itachi-splash

# Configure GRUB Splash Logo
mkdir -p /boot/grub
cp plymouth_theme/itachi_logo.png /boot/grub/itachi_logo.png
if [ -f /etc/default/grub ]; then
    sed -i '/GRUB_BACKGROUND/d' /etc/default/grub
    echo 'GRUB_BACKGROUND="/boot/grub/itachi_logo.png"' >> /etc/default/grub
    update-grub || true
fi

echo "[+] Step 6: Updating Initramfs with Custom Splash & Drivers..."
update-initramfs -u

echo "================================================================================"
echo "[+] SUCCESS: Micro-OS Live Environment Configured Successfully!"
echo "    - WiFi & LAN Stack: Active (NetworkManager & wpa_supplicant)"
echo "    - In-built APT & Aptitude: Configured & Verified"
echo "    - In-built Snap Store: Active (snapd)"
echo "    - Custom Boot Splash: Itachi Uchiha Theme Active"
echo "================================================================================"
