with open(r"C:\Users\sharm\.gemini\antigravity\brain\18b1549f-f6bd-4253-acd7-77b4b9e97d29\scratch\initrd_unpack\lib_livekitlib", "r", encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()

start = False
for i, line in enumerate(lines):
    if "change_root()" in line:
        start = True
    if start:
        print(f"{i+1}: {line.rstrip()}")
        if line.startswith("}") and i > 1490:
            break
