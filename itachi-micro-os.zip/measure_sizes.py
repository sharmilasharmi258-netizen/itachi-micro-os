import os

def get_dir_size(path):
    total = 0
    if not os.path.exists(path):
        return None
    for root, dirs, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            try:
                total += os.path.getsize(fp)
            except OSError:
                pass
    return total

# Check USB
usb_d = "D:\\"
if os.path.exists(usb_d):
    usb_total = get_dir_size(usb_d)
    print(f"USB_TOTAL: {usb_total / (1024*1024):.2f} MB ({usb_total:,} bytes)")
    
    slax_dir = "D:\\slax"
    if os.path.exists(slax_dir):
        slax_total = get_dir_size(slax_dir)
        print(f"SLAX_DIR: {slax_total / (1024*1024):.2f} MB")
        
    modules_dir = "D:\\slax\\modules"
    if os.path.exists(modules_dir):
        print("\nModules Breakdown:")
        for item in sorted(os.listdir(modules_dir)):
            ip = os.path.join(modules_dir, item)
            sz = os.path.getsize(ip) / (1024*1024)
            print(f"  - {item}: {sz:.2f} MB")
            
    boot_dir = "D:\\slax\\boot"
    if os.path.exists(boot_dir):
        print("\nKernel & Initrd Breakdown:")
        for item in sorted(os.listdir(boot_dir)):
            ip = os.path.join(boot_dir, item)
            if os.path.isfile(ip):
                sz = os.path.getsize(ip) / (1024*1024)
                print(f"  - {item}: {sz:.2f} MB")
else:
    print("Drive D: is not mounted right now.")

# Workspace size
ws = r"c:\Users\sharm\Downloads\micro os"
if os.path.exists(ws):
    ws_total = get_dir_size(ws)
    print(f"\nWORKSPACE_TOTAL: {ws_total / (1024*1024):.2f} MB ({ws_total:,} bytes)")
